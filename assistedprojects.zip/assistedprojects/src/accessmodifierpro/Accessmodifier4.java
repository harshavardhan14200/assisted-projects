package accessmodifierpro;


	import assistedprojects.*;

	public class Accessmodifier4  {

		public static void main(String[] args) {
			Accessmod g = new Accessmod  ();   
		       g.display();  
		}

	}

