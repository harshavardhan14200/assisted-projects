package accessmodifierpro;


	import assistedprojects.*;

	public class Accessmodifier3 extends accessmodifier {

		public static void main(String[] args) {
			Accessmodifier3 g = new Accessmodifier3  ();   
		       g.display();  
		}

	}


