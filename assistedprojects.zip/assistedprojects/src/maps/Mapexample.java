package maps;
import java.util.*;
public class Mapexample {
	public static void main(String[] args) {
		
		HashMap<Integer,String> hm=new HashMap<Integer,String>();     
		hm.put(1,"1");
        hm.put(2,"SECOND");
        hm.put(3,"THIRD");
		hm.put(4,"FOUR");
		System.out.println("\nThe elements of Hashmap are ");  
	    for(Map.Entry m:hm.entrySet()){    
	    System.out.println(m.getKey()+" "+m.getValue());    
	    }
        Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
	    ht.put(5,"five");  
	    ht.put(6,"six");  
	    ht.put(7,"seven");  
	    ht.put(8,"eight");  

	    System.out.println("\nThe elements of HashTable are ");  
	    for(Map.Entry n:ht.entrySet()){    
	    System.out.println(n.getKey()+" "+n.getValue());    
	    }
	    TreeMap<Integer,String> m=new TreeMap<Integer,String>();    
	    m.put(9,"nine");    
	    m.put(10,"ten");    
	    m.put(11,"eleven");       
	      
	    System.out.println("\nThe elements of TreeMap are ");  
	    for(Map.Entry l:m.entrySet()){    
	    System.out.println(l.getKey()+" "+l.getValue());    
	      }    
	      




}
	
}