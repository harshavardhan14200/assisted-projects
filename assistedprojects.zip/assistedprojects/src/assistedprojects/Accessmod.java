package assistedprojects;

public class Accessmod {
	public void display() 
    { 
        System.out.println(" Public Access Specifiers"); 
    } 
}



