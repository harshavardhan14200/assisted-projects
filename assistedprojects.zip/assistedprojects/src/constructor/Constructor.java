package constructor;


public class Constructor {
	
	    int id;  
	    String name;  
	    
	   public Constructor(){   
	    	System.out.println("inside");
	    	
	        }  
	      
	    public Constructor (int i,String n){   
		    id = i;  
		    name = n;  
	    }  
	    
	   
	    public void display()
	    {
	    	System.out.println(id+" "+name);
	    }  
	    
	   
	    public static void main(String args[]){  
	        Constructor s1 = new Constructor(123,"uday");  
	    	Constructor s2 = new Constructor(145,"manoj");    
	    s1.display();  
	    s2.display();  
	   }  
	}  

