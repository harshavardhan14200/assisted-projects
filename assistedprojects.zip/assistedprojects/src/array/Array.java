package array;

public class Array {


public static void main(String[] args) {

int h[]= {1,2,3,4,5,6,7};
for(int i=0;i<7;i++) {
System.out.println("Elements of array h: "+h[i]);
}

int[][] k = {
            {6,4,5,3}, 
            {4,8,7} };
      
      System.out.println("\nLength of row 2: " + k[1].length);
      }
}


