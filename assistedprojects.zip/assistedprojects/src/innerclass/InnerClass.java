package innerclass;

public class InnerClass {

		 private String msg="Welcome to world"; 
		 
		 class Inner{  
		  void hello(){System.out.println(msg+",  start learning Inner Classes");}  
		 }  


		public static void main(String[] args) {

			InnerClass obj=new InnerClass();
			InnerClass.Inner in=obj.new Inner();  
			in.hello();  
		}
	}
