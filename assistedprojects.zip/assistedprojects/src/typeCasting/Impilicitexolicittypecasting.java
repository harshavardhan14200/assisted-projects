package typeCasting;

public class Impilicitexolicittypecasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Implicit Type Casting");
		char b='B';
		System.out.println("Value of b: "+b);
		
		int i = 100;          
        long l = i;      
        System.out.println("long value "+ l);
		
		float c=b;
		System.out.println("Value of c: "+c);
		
		long d=b;
		System.out.println("Value of d: "+d);
		
		double e=b;
		System.out.println("Value of e: "+e);
		
				
		System.out.println("\n");
		
		System.out.println("Explicit Type Casting");
		
		double d2 = 100.04;
        long l2 = (long)d2;     
        int i2 = (int)l2;       
        System.out.println("Double value "+d2);
        System.out.println("Long value "+l2);
        System.out.println("Int value "+i2);
		
	}
}

