package collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Vector;

public class Collections {
public static void main(String[] args){
		
		ArrayList<String> al=new ArrayList<String>();  
		al.add("Hai");
		al.add("Hello");
		System.out.println(al);  
		
        
        System.out.println("\n");
	    LinkedHashSet<Integer> s1=new LinkedHashSet<Integer>(); 
	    s1.add(10);  
	    s1.add(23);  
	    s1.add(34);
	    s1.add(74);	       
	    System.out.println(s1);
	    
	    System.out.println("\n");
	    HashSet<Integer> s2=new HashSet<Integer>();  
	    s2.add(163);  
	    s2.add(160);  
	    s2.add(152);
	    s2.add(164);
	    s2.add(167);
	    System.out.println(s2);
	    
	    System.out.println("\n");
	    Vector<Integer> vec = new Vector();
	    vec.addElement(7); 
	    vec.addElement(30); 
	    System.out.println(vec);
	    
	    System.out.println("\n");
	    LinkedList<String> l1=new LinkedList<String>();  
	    l1.add("monish");  
	    l1.add("peter");  	      
	    Iterator<String> itr=l1.iterator();  
	    while(itr.hasNext()){  
	    System.out.println(itr.next());  




	      }
}
}
        



