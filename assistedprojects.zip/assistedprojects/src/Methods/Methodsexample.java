package Methods;

public class Methodsexample {
	public static void main(String[] args) {
	      int x = 11;
	      int y = 6;
	      int z = maxFunction(x, y);
	      System.out.println("maximum Value = " + z);
	   }

	   
	   public static int maxFunction(int n1, int n2) {
	      int max;
	      if (n1 < n2)
	         max = n2;
	      else
	         max = n1;

	      return max; 
	   }
}


