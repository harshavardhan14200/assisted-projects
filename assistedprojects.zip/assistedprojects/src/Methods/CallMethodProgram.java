package Methods;

public class CallMethodProgram {
	static void change(int a)
    {
        
        a = a + 50;
    }
 
    public static void main(String[] args)
    { 
        int a = 30;
        System.out.println("before change a = " + a);
        change(a);
        System.out.println("after change a = " + a);
    }
}

