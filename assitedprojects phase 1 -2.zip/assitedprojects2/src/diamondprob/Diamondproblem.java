package diamondprob;
interface DemoInterface1  
{  
public default void display()   
{  
System.out.println(" DemoInterface1 invoked");  
}  
}  
interface DemoInterface2  
{  
public default void display()   
{  
System.out.println(" DemoInterface2 invoked");  
}  
}  
public class Diamondproblem implements DemoInterface1, DemoInterface2  
{  
public void display()   
{  
DemoInterface1.super.display();  
DemoInterface2.super.display();  
}  
public static void main(String args[])   
{  
	Diamondproblem obj = new Diamondproblem();  
obj.display();  
}  
}  
