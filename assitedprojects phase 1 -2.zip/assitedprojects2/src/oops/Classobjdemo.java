package oops;

public class Classobjdemo {
	     
	    String brand; 
	    int tankcapacity; 
	    String color; 
	    public Classobjdemo( String brand ,int tankcapacity, String color)
	    { 
	         
	        this.brand = brand; 
	        this.tankcapacity = tankcapacity; 
	        this.color = color; 
	    } 
	    
	    public String getBrand() 
	    { 
	        return brand; 
	    } 
	    public int getTankcapacity() 
	    { 
	        return tankcapacity; 
	    } 
	    public String getColor() 
	    { 
	        return color; 
	    } 
	    @Override
	    public String toString() 
	    { 
	        return(  "\n brand name is" + this.getBrand()+ " tankcapacity is " + this.getTankcapacity()+ ", and color is "+ this.getColor() + "."); 
	    } 
	    

		public static void main(String[] args) 
	    { 
	    	Classobjdemo scott = new Classobjdemo ("honda",5,"red"); 
	        System.out.println(scott.toString()); 
	    } 
	}


