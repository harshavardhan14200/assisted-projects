package thread;

	public class Multi implements Runnable{
	    public static int myCount = 0;
		    public void run() {
			while(Multi.myCount <= 10){
	            try{
	                System.out.println("main Thread: "+(++Multi.myCount));
	                Thread.sleep(1000);
	            } catch (InterruptedException iex) {
	                System.out.println("Exception in thread: "+iex.getMessage());
	            }

		        }
		    } 
		    public static void main(String a[]){
		    System.out.println("Starting Main Thread...");
		    Multi h = new Multi();
		    Thread t = new Thread(h);
		    t.start();
		    }
			
}