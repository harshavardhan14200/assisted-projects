package queue;
import java.util.*;
import java.util.LinkedList;

public class Queuedemo {
	public static void main(String[] args) 
	{
	 Queue<String> fruitsQueue = new LinkedList<>();
	                fruitsQueue.add("mango");
	                fruitsQueue.add("apple");
	                fruitsQueue.add("kiwi");
                	System.out.println("Queue is : " + fruitsQueue);
	        		System.out.println("Head of Queue : " + fruitsQueue.peek());
	        		fruitsQueue.remove();
	        		System.out.println("After removing Head of Queue : " + fruitsQueue);
	        		
	    	}
	}


